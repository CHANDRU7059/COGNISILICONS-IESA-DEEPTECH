# My First Project > 2026-02-07 12:29pm
https://universe.roboflow.com/sem-defect/my-first-project-lcdfi

Provided by a Roboflow user
License: CC BY 4.0

